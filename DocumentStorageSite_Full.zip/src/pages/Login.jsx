import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [otp, setOtp] = useState('');
  const [otpToken, setOtpToken] = useState(null);
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      const res = await axios.post('/login', { email, password });
      setOtpToken(res.data.otpToken);
      setMessage('OTP sent to your email.');
    } catch (err) {
      setMessage(err.response?.data?.error || 'Login failed');
    }
  };

  const handleOtpVerify = async () => {
    try {
      await axios.post('/login/verify-otp', { otpToken, otp });
      setMessage('Login successful. Redirecting...');
      navigate('/dashboard');
    } catch (err) {
      setMessage(err.response?.data?.error || 'OTP verification failed');
    }
  };

  return (
    <div>
      <h2>Login</h2>
      {!otpToken ? (
        <>
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <button onClick={handleLogin}>Send OTP</button>
        </>
      ) : (
        <>
          <input
            type="text"
            placeholder="Enter OTP"
            value={otp}
            onChange={(e) => setOtp(e.target.value)}
          />
          <button onClick={handleOtpVerify}>Verify OTP & Login</button>
        </>
      )}
      <p>{message}</p>
    </div>
  );
}
